﻿/*
* Plugin DevVN Woocommerce Reviews
* Author: https://levantoan.com
*/

== Những thay đổi ==

= V1.1.3 - 15.02.2020 =
* Gửi review bằng Ajax
* Thêm avatar trong reviews
* Thêm link edit comment ở mỗi comment
* Thêm shortcode [devvn_reviews] để hiển thị comments_template
* Fix js + css với theme porto
    /*Css for Porto theme*/
    div#reviews.woocommerce-Reviews, .devvn_prod_cmt {
        max-width: 100%;
    }
    .devvn-star:before {
        content: "";
        font-style: normal;
        font-family: 'Font Awesome 5 Free';
        font-weight: 900;
    }
    form#commentform {
        padding: 0;
        background: #fff;
    }
    #review_form .comment-form-rating p.stars a:before, .woocommerce #reviews #comments ol.commentlist #respond .comment-form-rating p.stars a:before {
        content: "";
    }
    .single-product .star_box .woocommerce-product-rating:after {
        display: none;
    }
    #reviews .commentlist li {
        padding-left: 0;
    }
    .commentlist li .comment-text {
        background: #fff;
    }
    #reviews .commentlist li .comment-text:before {
        display: none;
    }
    .commentlist li .comment-text p {
        font-size: 14px;
    }
    #reviews .commentlist li .star-rating {
        float: none;
    }
    /*#Css for Porto theme*/

= V1.1.2 - 02.12.2019 =

* Add: Thêm chức năng bật "cho phép đánh giá" cho toàn bộ sản phẩm
* Add: Thêm chức năng hỗ trợ lên lịch đăng review khi import bằng csv. Theo hướng dẫn này https://www.youtube.com/watch?v=85l4Juyeu_s
       Nghĩa là khi import mà ngày review lớn hơn ngày hiện tại thì review đó sẽ được lên lịch đăng mà không đăng ngay lúc import

= V1.1.1 - 19.11.2019 =
* Tắt transient cho bộ đếm số sao đánh giá
* Thêm language cho plugin. Mặc định là tiếng anh, đã có sẵn tiếng việt và .pot
* Sửa lỗi khi chọn nhiều ảnh quá dung lượng cho phép thì không hể up tiếp các ảnh sau

= V1.1.0 - 29.10.2019 =
* Fix: Sửa lỗi không up được ảnh khi sử dụng safari trên iphone
* Update: Thêm option số lượng hình ảnh được up lên khi đánh giá. Mặc định là 3 hình

= V1.0.9 - 04.10.2019 =

* Add: Thêm nút thích trong từng review và bình luận (Option)
* Update: Có thể sửa label "Đã mua hàng tại..."

= V1.0.8 - 26.09.2019 =

* Fix: Chuyển trang comment sẽ nhảy tới đúng mục comment trong trang hiện tại
* Add: Ẩn ngày đánh giá và bình luận (tùy chỉnh)
* Add: Thêm chức năng tắt bình luận. Chỉ để đánh giá sản phẩm
* Add: Thêm chức năng fake label đã mua hàng cho từng review trong admin

= V1.0.7 - 10.08.2019 =

* Fix: Đếm lại tổng số review. đã loại trừ các review của admin trả lời trong admin

= V1.0.6  - 05.08.2019 =
* New: Thêm công cụ fake label xác nhận đã mua hàng
* Update: Thêm hiển thị list hình ảnh trong admin để dễ quản lý
* Add: Thêm ô nhập tên action để tùy biến vị trí reviews
* Update: Thêm tính năng bỏ upload ảnh khi đánh giá
* Fix: 1 số lỗi nhỏ

= V1.0.5  - 04.08.2019 =
* New: Thay đổi folder upload hình ảnh thành wp-content/uploads/woocommerce-reviews
* New: Loại bỏ các size ảnh khác chỉ để lại thumbnail và full size khi upload ảnh trong comment. Sẽ tối ưu số ảnh và dụng lượng cho hosting của bạn
* Add: Thêm chức năng chuyển đổi từ review cũ của website để tương thích với plugin
* Add: Thêm label "Quản trị viên" cho phần reviews

= V1.0.4  - 03.08.2019 =
* Update: Thêm phần chú ý sau khi cài đặt. Bỏ bắt buộc email trong setting https://levantoan.com/san-pham/devvn-woocommerce-reviews/#chu-y
* Fix: Sửa một số cảnh báo nhỏ

= V1.0.3  - 02.08.2019 =
* Fix: Sủa lỗi trả lời nhanh trong admin không hiện ra bên ngoài

= V1.0.2  - 02.08.2019 =
* Update: Thêm ô nhập vị trí ưu tiên hiển thị
* Fix: 1 số lỗi css trên flatsome theme

= V1.0.1  - 02.08.2019 =
* Fix: Sửa lỗi thiếu thư viện js wp.template

= V1.0.0 - 01.08.2019 =
* Ra mắt plugin